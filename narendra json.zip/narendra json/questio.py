import json

def productload(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def productsave(file_path, products):
    with open(file_path, 'w') as file:
        json.dump(products, file, indent=4)

def add(file_path):
    products = productload(file_path)
    new_product = {
        "id": int(input("Enter product ID: ")),
        "name": input("Enter product name: "),
        "category": input("Enter product category: "),
        "price": float(input("Enter product price: ")),
        "available": input("Is the product available? (true/false): ").lower() == "true"
    }
    products.append(new_product)
    productsave(file_path, products)
    print("Product added successfully.")

def updateprice(file_path):
    products = productload(file_path)
    product_id = int(input("Enter product ID to update: "))
    new_price = float(input("Enter new price: "))
    for product in products:
        if product['id'] == product_id:
            product['price'] = new_price
            productsave(file_path, products)
            print("Price updated successfully.")
            return
    print("Product not found.")

def filters(file_path):
    products = productload(file_path)
    available_products = [product for product in products if product['available']]
    print("Available products:")
    for product in available_products:
        print(product)

def filter_by_category(file_path):
    products = productload(file_path)
    category = input("Enter category to filter: ")
    filtered_products = [product for product in products if product['category'].lower() == category.lower()]
    print(f"Products in category '{category}':")
    for product in filtered_products:
        print(product)


file = 'product.json'
while True:
    print("\nChoose option:")
    print("1. Add  product")
    print("2. Update price")
    print("3. available products")
    print("4. products by category")
    print("Type 'over' to exit.")
    
    choice = input("Enter your choice: ").strip()
    
    if choice == "1":
        add(file)
    elif choice == "2":
        updateprice(file)
    elif choice == "3":
        filters(file)
    elif choice == "4":
        filter_by_category(file)
    elif choice == "over":
        print("Done")
        break
    else:
        print("Invalid choice. Please try again.")

